/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/*
Escreva um programa em linguagem Java que: 

1)Entrar com um número e imprimi-lo caso seja maior que 20.

2)leia dois valores numéricos inteiros e efetue a adição. Caso o resultado seja maior que 10, apresentá-lo.

3)Entrar com um número e imprimir a raiz quadrada do número caso ele seja positivo e o quadrado do número caso ele seja negativo.

4)Entrar com um número e imprimir uma das mensagens: é múltiplo de 3 ou não é múltiplo de 3.

5)Entrar com um número e informar se ele é divisível por 3 e por 7.

6)Entrar com um número e informar se ele é divisível por 10, por 5, por 2 ou se não é divisível por nenhum destes.
*/

package atividade_1;

import java.util.Scanner;
public class Atividade_1 
{
  
    public static void main(String[] args) 
    {
     Scanner ent = new Scanner(System.in);
     
     //PRIMEIRA QUESTÃO
     
     int num;
        
        System.out.println("PRIMEIRA QUESTÃO\n");
        System.out.println("Informe um número maior que 20 para exibi-lo na tela: "); 
        num = ent.nextInt();
        
        if(num > 20)
        {
            System.out.println("\nO valor informado foi: " +num);
        } 
        
     //SEGUNDA QUESTÃO
     
     int[] num2 = new int[2];
     int soma;
     
        System.out.println("\n\n=====================================================\n");
        System.out.println("SEGUNDA QUESTÃO\n");
        System.out.println("Insira dois valores cuja somatória seja maior que 10\n");
        
        for(int i=0; i<2; i++)
        {
            System.out.println("Informe o " + (i+1) +"º número inteiro: ");
            num2[i] = ent.nextInt(); 
        }
        
        soma = num2[0] + num2[1];

        if(soma > 10)
        {
            System.out.println("\nA soma dos dois valores é: " +soma);
        } 
        
     //TERCEIRA QUESTÃO
     
     int num3, quad;
     
        System.out.println("\n\n=====================================================\n");
        System.out.println("TERCEIRA QUESTÃO\n");
        System.out.println("Informe um número inteiro positivo para descobrir sua raiz quadrada ou um número negativo para descobrir seu valor ao quadrado\n");
        
        System.out.println("Insira o valor: ");
        num3 = ent.nextInt();
        
        if(num3 > 0)
        {
            System.out.println("Raiz de " +num3 +" = " +Math.sqrt(num3));
        }
        else
        {
            quad = num3 * 2;
            System.out.println("Quadrado de " +num3 +" = " +quad);
        } 
        
        //QUARTA QUESTÃO
        
        int num4;
        
        System.out.println("\n\n=====================================================\n");
        System.out.println("QUARTA QUESTÃO\n");
        System.out.println("Informe um número inteiro para descobrir se é múltiplo de 3 ou não: \n");
        
        System.out.println("Informe um número inteiro: ");
        num4 = ent.nextInt();
        
        if(num4 %3 == 0)
        {
            System.out.println("\n" +num4 +" É múltiplo de 3");
        }
        else 
        {
            System.out.println("\n" +num4 +" NÃO é múltiplo de 3");
        } 
        
        //QUINTA QUESTÃO
        
        int num5;
        
        System.out.println("\n\n=====================================================\n");
        System.out.println("QUINTA QUESTÃO\n");
        System.out.println("Informe um número inteiro para descobrir se é divisível por 3 e por 7: \n");
        
        System.out.println("Informe um número inteiro: ");
        num5 = ent.nextInt();
        
        if(num5 %3 == 0 && num5 %7 == 0)
        {
            System.out.println("\n" +num5 +" É divisível por 3 e 7");
        }
            else if(num5 %3 == 0 && num5 %7 != 0)
            {
                System.out.println("\n" +num5 +" É divisível por 3 mas não por 7");
            }
                else if(num5 %3 != 0 && num5 %7 == 0)
                {
                    System.out.println("\n" +num5 +" É divisível por 7 mas não por 3");
                }
                    else
                    {
                        System.out.println("\n" +num5 +" NÃO é divisível por 3 nem por 7");
                    } 
        
        //SEXTA QUESTÃO
        
        int num6;
        
        System.out.println("\n\n=====================================================\n");
        System.out.println("SEXTA QUESTÃO\n");
        System.out.println("Informe um número inteiro para descobrir se é múltiplo de 10, 5 ou 2: \n");
        
        num6 = ent.nextInt();
        
     //OPÇÕES DE TEXTO=========================================================
     
    //TODOS MÚLTIPLOS
       if(num6 %10 == 0 && num6 %5 == 0 && num6 %2 == 0)
       {
           System.out.println("\n" +num6 +" É múltiplo de 10, 5 e 2");
       }
        
        //SOMENTE 10
               else if(num6 %10 == 0 && num6 %5 != 0 && num6 %2 != 0)
               {
                   System.out.println("\n" +num6 +" É múltiplo de 10 mas não de 5 nem de 2");
               }

            //SOMENTE 5
                else if(num6 %5 == 0 && num6 %10 != 0 && num6 %2 != 0)
                {
                    System.out.println("\n" +num6 +" É múltiplo de 5 mas não de 10 nem de 2");
                }

                //SOMENTE 2           
                    else if(num6 %2 == 0 && num6 %10 != 0 && num6 %5 != 0)
                    {
                        System.out.println("\n" +num6 +" É múltiplo de 2 mas não de 10 nem de 5");
                    }

                    //SOMENTE 10 E 5
                        else if(num6 %10 == 0 && num6 %5 == 0 && num6 %2 != 0)
                        {
                            System.out.println("\n" +num6 +" É múltiplo de 10 e 5, mas não de 2");
                        }

                //SOMENTE 10 E 2
                    else if(num6 %10 == 0 && num6 %2 == 0 && num6 %5 != 0)
                    {
                        System.out.println("\n" +num6 +" É múltiplo de 10 e 2, mas não de 5");
                    }

            //SOMENTE 5 E 2
                else if(num6 %5 == 0 && num6 %2 == 0 && num6 %10 != 0)
                {
                    System.out.println("\n" +num6 +" É múltiplo de 5 e 2, mas não de 10");
                }
                                
    //NENHUM MÚLTIPLO               
        else
        {
            System.out.println("\n" +num6 +" NÃO é múltiplo de nenhum dos números");
        }
       
    }
    
}
