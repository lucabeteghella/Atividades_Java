/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarefa_classe.animal_16_10;

/**
 *
 * @author lucab
 */
public class Animal 
{
    // Atributos 
      public int patas;
      
      public Animal(int patas)
            {
                this.patas = patas;
            }
      
    //Métodos 
      public void mover()
      {
          System.out.println("Movendo");
      }
      
      public void comer()
      {
          System.out.println("Comendo");
      }
      
      public void imprimir()
      {
          
      }
      
      
}
