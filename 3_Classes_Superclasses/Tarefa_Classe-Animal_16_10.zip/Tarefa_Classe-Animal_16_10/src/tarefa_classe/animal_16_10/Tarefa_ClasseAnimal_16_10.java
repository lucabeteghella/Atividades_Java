/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tarefa_classe.animal_16_10;

/**
 *
 * @author lucab
 */
public class Tarefa_ClasseAnimal_16_10
{
    
    public static void main(String[] args) 
    {
        Animal a;
        
        a = new Ave(2);
        a.imprimir(); 
        
        System.out.println("\n");
        
        a = new Cachorro(4);
        a.imprimir(); 
    }
    
}
