/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarefa_classe.animal_16_10;

/**
 *
 * @author lucab
 */
public class Cachorro extends Animal
{
    //Cachorro herdando os ATRIBUTOS da classe Animal
    public Cachorro(int patas)
    {
        //superclasse
        super (patas);
    }
    
    
    //Cachorro herdando os MÉTODOS da classe Animal
    
    /*
      A anotação @Override explicita que o método declarado está SOBRESCREVENDO um método de mesma assinatura 
      declarado na superclasse ou na interface que está sendo estendida/implementada pela sua classe.
    */
    @Override
    public void mover()
    {
        System.out.println("Movimentação: corre");
    }
    
    @Override
    public void comer()
    {
        System.out.println("Alimentação: come ração");
    }
    
    @Override
    public void imprimir()
    {
        System.out.println("Características do Cachorro \nPatas: " +patas);
        this.mover();
        this.comer();
    }
    
}
