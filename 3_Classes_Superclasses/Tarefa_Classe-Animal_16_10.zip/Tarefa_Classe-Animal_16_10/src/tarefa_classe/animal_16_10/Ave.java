/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tarefa_classe.animal_16_10;

/**
 *
 * @author lucab
 */
public class Ave extends Animal
{
    //Ave herdando os ATRIBUTOS da classe Animal
    public Ave(int patas)
    {
        //superclasse
        super (patas);
    }
    
    
    //Ave herdando os MÉTODOS da classe Animal
    
    /*
      A anotação @Override explicita que o método declarado está SOBRESCREVENDO um método de mesma assinatura 
      declarado na superclasse ou na interface que está sendo estendida/implementada pela sua classe.
    */
    @Override
    public void mover()
    {
        System.out.println("Movimentação: voa");
    }
    
    @Override
    public void comer()
    {
        System.out.println("Alimentação: sementes");
    }
    
    @Override
    public void imprimir()
    {
        System.out.println("Características da Ave \nPatas: " +patas);
        this.mover();
        this.comer();
    }
}
